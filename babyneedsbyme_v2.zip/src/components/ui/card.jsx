
import React from "react";

export function Card({ children }) {
  return (
    <div className="rounded-xl shadow-lg overflow-hidden">{children}</div>
  );
}

export function CardContent({ children }) {
  return <div className="p-4">{children}</div>;
}
    