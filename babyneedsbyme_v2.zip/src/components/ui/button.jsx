
import React from "react";

export function Button({ children, className, ...props }) {
  return (
    <button
      {...props}
      className={`py-2 px-4 rounded-md font-medium transition ${className}`}
    >
      {children}
    </button>
  );
}
    