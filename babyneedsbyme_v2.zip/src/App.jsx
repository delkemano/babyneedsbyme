
import React from "react";
import { Button } from "./components/ui/button";
import { Card, CardContent } from "./components/ui/card";
import { motion } from "framer-motion";
import { ShoppingBag } from "lucide-react";

const products = [
  {
    id: 1,
    name: "Speenkoord Naturel",
    description: "Handgemaakt met houten kralen en een neutrale uitstraling.",
    price: "€12,95",
    priceValue: 12.95,
    image: "https://images.unsplash.com/photo-1607083206173-3523e1d188d7",
  },
  {
    id: 2,
    name: "Speenkoord Pastel",
    description: "Zachte kleuren en siliconen kralen voor extra veiligheid.",
    price: "€14,95",
    priceValue: 14.95,
    image: "https://images.unsplash.com/photo-1595433562696-19b6b9e850f2",
  },
];

function handleCheckout(product) {
  alert(`Je wordt doorgestuurd naar de betaalpagina voor: ${product.name} (€${product.priceValue.toFixed(2)})`);
}

export default function HomePage() {
  return (
    <div className="min-h-screen bg-pink-50 p-6">
      <header className="mb-10 text-center">
        <h1 className="text-4xl font-bold text-pink-700 mb-2">babyneedsbyme</h1>
        <p className="text-lg text-pink-600">Handgemaakte speenkoorden met liefde</p>
      </header>
      <section className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-4xl mx-auto">
        {products.map((product) => (
          <motion.div
            key={product.id}
            whileHover={{ scale: 1.03 }}
            className="shadow-xl rounded-2xl overflow-hidden bg-white"
          >
            <Card>
              <img
                src={product.image}
                alt={product.name}
                className="w-full h-60 object-cover"
              />
              <CardContent className="p-4">
                <h2 className="text-xl font-semibold text-pink-800">{product.name}</h2>
                <p className="text-sm text-gray-600 mb-2">{product.description}</p>
                <div className="flex justify-between items-center">
                  <span className="text-pink-700 font-bold">{product.price}</span>
                  <Button
                    className="bg-pink-600 hover:bg-pink-700 text-white"
                    onClick={() => handleCheckout(product)}
                  >
                    <ShoppingBag className="w-4 h-4 mr-1" /> Bestel
                  </Button>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </section>
      <footer className="mt-12 text-center text-pink-500 text-sm">
        © {new Date().getFullYear()} babyneedsbyme. Alle rechten voorbehouden.
      </footer>
    </div>
  );
}
    